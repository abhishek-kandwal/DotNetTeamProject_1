﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EF3.Models;

namespace EF3.Controllers
{
    public class UserRegistrationsController : Controller
    {
        private Training2019Entities db = new Training2019Entities();

        // GET: UserRegistrations
        public ActionResult Index()
        {
            var data = db.sp_getDetails();
            return View(data.ToList());
            //return View(db.UserRegistrations.ToList());
        }
        //public ActionResult Details()
        //{
        //    var data = db.sp_getDetails();
        //    return View(data.ToList());
        //}

        // GET: UserRegistrations/Details/5


        //public ActionResult Details(string id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    UserRegistration userRegistration = db.UserRegistrations.Find(id);
        //    if (userRegistration == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(userRegistration);
        //}

        //GET: UserRegistrations/Create
        public ActionResult Create()
        {
            return View();
        }
        

        // POST: UserRegistrations/Create

        [HttpPost]
        [ValidateAntiForgeryToken]

        //public ActionResult Create([Bind(Include = "Name,Address,PhoneNo,Email,State,Approved")] UserRegistration userRegistration)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.UserRegistrations.Add(userRegistration);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(userRegistration);
        //}
        public ActionResult Create(UserRegistration collection)
        {
            try
            {
                //SqlParameter param1 = new SqlParameter("@Name", collection.Name);
                //SqlParameter param2 = new SqlParameter("@Address", collection.Address);
                //SqlParameter param3 = new SqlParameter("@PhoneNo", collection.PhoneNo);
                //SqlParameter param4 = new SqlParameter("@Email", collection.Email);
                //SqlParameter param5 = new SqlParameter("@State", collection.State);
                db.sp_createNewStudent(collection.Name, collection.Address, collection.PhoneNo, collection.Email, collection.State, false);

                //var data = db.Database.ExecuteSqlCommand("sp_createNewStudent @Name, @Address, @PhoneNo,@Email,@State", param1, param2, param3, param4, param5);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        // GET: UserRegistrations/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserRegistration userRegistration = db.UserRegistrations.Find(id);
            if (userRegistration == null)
            {
                return HttpNotFound();
            }
            return View(userRegistration);
        }

        // POST: UserRegistrations/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Name,Address,PhoneNo,Email,State,Approved")] UserRegistration userRegistration)
        {
            if (ModelState.IsValid)
            {
                db.Entry(userRegistration).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(userRegistration);
        }

        // GET: UserRegistrations/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserRegistration userRegistration = db.UserRegistrations.Find(id);
            if (userRegistration == null)
            {
                return HttpNotFound();
            }
            return View(userRegistration);
        }

        // POST: UserRegistrations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            UserRegistration userRegistration = db.UserRegistrations.Find(id);
            db.UserRegistrations.Remove(userRegistration);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
