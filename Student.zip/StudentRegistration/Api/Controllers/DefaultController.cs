﻿using Api.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using DataService;

namespace Api.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class DefaultController : ControllerBase
    {
        // GET: api/Default
        [HttpGet(Name = "GetUsers")]
        public DataTable GetUsers()
        {
            DataTable dtUsers = new DataHelper().GetResults("SELECT * FROM UserRegistration");            return dtUsers;
        }



        // GET: api/Default/5
        [HttpGet(Name = "SearchResult")]
        public DataTable SearchResult([FromQuery] SearchModel searchModel)
        {
            string query = string.Empty;
            bool whereClauseRequired = false;

            query = "SELECT * FROM UserRegistration WHERE";

            if (!string.IsNullOrWhiteSpace(searchModel.Name))
            {
                query = query + " Name = '" + searchModel.Name + "'";
                whereClauseRequired = true;
            }

            if (!string.IsNullOrWhiteSpace(searchModel.Address))
            {
                if (whereClauseRequired)
                {
                    query = query + " AND";
                }
                query = query + " Address = '" + searchModel.Address + "'";
                whereClauseRequired = true;
            }

            if ((searchModel.PhoneNo) != 0)
            {
                if (whereClauseRequired)
                {
                    query = query + " AND";
                }
                query = query + " PhoneNo = '" + searchModel.PhoneNo + "'";
                whereClauseRequired = true;
            }

            if (!string.IsNullOrWhiteSpace(searchModel.Email))
            {
                if (whereClauseRequired)
                {
                    query = query + " AND";
                }
                query = query + " Email = '" + searchModel.Email + "'";
                whereClauseRequired = true;
            }

            if (!string.IsNullOrWhiteSpace(searchModel.State))
            {
                if (whereClauseRequired)
                {
                    query = query + " AND";
                }
                query = query + " State = '" + searchModel.State + "'";
                whereClauseRequired = true;
            }

            if (searchModel.Approved)
            {
                if (whereClauseRequired)
                {
                    query = query + " AND";
                }
                query = query + " Approved = '" + searchModel.Approved + "'";
                whereClauseRequired = true;
            }

            DataTable dtUsers = new DataHelper().GetResults(query);
            return dtUsers;
        }
        [HttpGet(Name = "Register")]
        public DataTable Register([FromQuery] SearchModel searchModel)
        {
            DataTable dtUsers = new DataHelper().PostValues("INSERT INTO UserRegistration VALUES ('" + searchModel.Name + "' , '" + searchModel.Address + "','" + searchModel.PhoneNo + "','" + searchModel.Email + "','" + searchModel.State + "','" + searchModel.Approved + "')");
            return dtUsers;

        }
        [HttpGet(Name = "GetUser")]
        public DataTable GetUser(string name)
        {
            DataTable dtusers = new DataHelper().GetResults("SELECT * FROM UserRegistration WHERE Name = '" + name + "'");
            return dtusers;
        }


        [HttpGet(Name = "Update")]
        public DataTable Update([FromQuery] SearchModel searchModel)
        {

            DataTable dtUsers = new DataHelper().GetResults("UPDATE UserRegistration SET Approved = '" + searchModel.Approved + "' WHERE Name = '" + searchModel.Name + "';");
            return dtUsers;
        }
    }
}
