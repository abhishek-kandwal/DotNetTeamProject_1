﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication5.Models
{
    public class Student
    {
        public string StudentID { get; set;}
        public string StudentName { get; set; }
        public string StudentPercentage { get; set; }
        public string StudentCity { get; set; }
        public string StudentAge { get; set; }
        public string StudentGender { get; set; }

    }
    public class createStudent : Student
    {

    }

    public class ReadStudent:Student
    {
        public ReadStudent(DataRow row)//read row wise
        {
            StudentID = Convert.ToInt32(row["StudentID"]);
            StudentName = row["StudentName"].ToString();
            StudentPercentage = Convert.ToInt32(row["StudentPercentage"]);
            StudentCity = row["StudentCity"].ToString();
            StudentAge = Convert.ToInt32(row["StudentAge"]);
            StudentGender = row["StudentGender"].ToString();

        }
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int StudentPercentage { get; set; }
        public string StudentCity { get; set; }
        public int StudentAge { get; set; }
        public string StudentGender { get; set; }
    }
}
