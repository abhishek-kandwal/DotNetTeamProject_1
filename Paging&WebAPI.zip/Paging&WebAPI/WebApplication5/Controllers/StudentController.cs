﻿using System;
using WebApplication5.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        //sql connection
         SqlConnection sqlCon;
         SqlDataAdapter sqlDa;


        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<Student> Get()//complex type pamaeter binding; IEnumerable where looping is possible
        {
            sqlCon = new SqlConnection("Data Source=DESKTOP-B5L51RH; Initial Catalog=StudentDB; Integrated Security=true");
            DataTable dataTable = new DataTable();
            var query = "select * from StudentInfo";
            sqlDa = new SqlDataAdapter
            {
                SelectCommand = new SqlCommand(query, sqlCon)
        };
            sqlDa.Fill(dataTable);
            List<Student> students = new List<Models.Student>(dataTable.Rows.Count);
            if(dataTable.Rows.Count>0)
            {
                foreach(DataRow studentRecord in dataTable.Rows)
                {
                    students.Add(new ReadStudent(studentRecord));
                }
            }
            return students;
        }

        // GET api/<controller>/5
        //[HttpGet("{StudentID}")] //student id is random(for eg- take 67 for testing)
        //public IEnumerable<Student> Get(int StudentID)
        //{
        //    //sqlCon = new SqlConnection("Data Source=DESKTOP-B5L51RH; Initial Catalog=StudentDB; Integrated Security=true");
        //    DataTable dataTable = new DataTable();
        //    var query = "select * from StudentInfo where StudentID="+ StudentID;
        //    sqlDa = new SqlDataAdapter
        //    {
        //        SelectCommand = new SqlCommand(query, sqlCon)
        //    };
        //    sqlDa.Fill(dataTable);
        //    List<Student> students = new List<Models.Student>(dataTable.Rows.Count);
        //    if (dataTable.Rows.Count > 0)
        //    {
        //        foreach (DataRow studentRecord in dataTable.Rows)
        //        {
        //            students.Add(new ReadStudent(studentRecord));
        //        }
        //    }
        //    return students;
         
        //}

        // POST api/<controller>
        [HttpPost]
        public string Post(Student student)
        {
           sqlCon = new SqlConnection("Data Source=DESKTOP-B5L51RH; Initial Catalog=StudentDB; Integrated Security=true");
            var query = "Insert into StudentInfo(StudentID, StudentName, StudentPercentage,  StudentCity, StudentAge, StudentGender) Values(@StudentID, @StudentName, @StudentPercentage,  @StudentCity, @StudentAge, @StudentGender)";
            SqlCommand insertCommand = new SqlCommand(query,sqlCon);
            insertCommand.Parameters.AddWithValue("@StudentID", student.StudentID);
            insertCommand.Parameters.AddWithValue("@StudentName", student.StudentName);
            insertCommand.Parameters.AddWithValue("@StudentPercentage", student.StudentPercentage);
            insertCommand.Parameters.AddWithValue("@StudentCity", student.StudentCity);
            insertCommand.Parameters.AddWithValue("@StudentAge", student.StudentAge);
            insertCommand.Parameters.AddWithValue("@StudentGender", student.StudentGender);
            sqlCon.Open();
            int result = insertCommand.ExecuteNonQuery();
            if (result > 0)
            {
                return "true";
            }
            else
            {
                return "false";
            }


        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
